package com.osmanacikgoz.api.services

import com.osmanacikgoz.api.response.PokedexResponse
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query

interface PokedexServices {
    @GET("v2/pokemon/")
    fun listPoke(@Query("name") name:String): Call<List<PokedexResponse>>
}