package com.osmanacikgoz.api.client

object Constant {

    val BASE_URL ="https://pokeapi.co/api/v2/pokemon/"
}