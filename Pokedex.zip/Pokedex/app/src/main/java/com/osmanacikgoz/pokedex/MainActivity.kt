package com.osmanacikgoz.pokedex

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.osmanacikgoz.api.client.ApiClient
import com.osmanacikgoz.api.response.PokedexResponse
import com.osmanacikgoz.api.services.PokedexServices
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {
    lateinit var pokedexServices:PokedexServices
    lateinit var pokeList : MutableList<PokedexResponse>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        pokedexServices =ApiClient.getClient().create(PokedexServices::class.java)
        var pokedex = pokedexServices.listPoke("balbazar")

        pokedex.enqueue(object :Callback<List<PokedexResponse>>{
            override fun onResponse(call: Call<List<PokedexResponse>>, response: Response<List<PokedexResponse>>) {
                if (response.isSuccessful){
                    pokeList = (response.body() as MutableList<PokedexResponse>)
                }
            }

            override fun onFailure(call: Call<List<PokedexResponse>>, t: Throwable) {

                Toast.makeText(applicationContext, t.message.toString(), Toast.LENGTH_LONG).show()
            }

        })


    }
}